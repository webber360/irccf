<!-- Paste this section into the CLAUDE.md of every W360 website project. Replace X.Y.Z. -->

## Cookie consent (@webber360/consent vX.Y.Z)

- Consent comes ONLY from `@webber360/consent`, pinned to one release:
  Astro → `vendor/webber360-consent-X.Y.Z.tgz` installed with `npm i ./vendor/…tgz`;
  WordPress → the "W360 Consent" plugin from the same release. Never copy its code into this
  site or patch it here; changes go to the webber360/consent repo as a new release.
- Upgrading means downloading a newer release file and installing it; that is a dependency
  upgrade and needs Pierre's approval like any other. Steps: "Upgrading a site" in the
  package README.
- Never add Google (GA4, Ads, GTM), Meta, LinkedIn, Hotjar or any other tracking/marketing
  script directly. Configure it in the consent config, or wrap it:
  `<script type="text/plain" data-consent="marketing" data-src="…">`, or load it from
  `onConsent()`. Embeds that set cookies (YouTube, maps) use `data-consent` + `data-src`, or
  a click-to-load placeholder.
- Astro: `<ConsentHead config={consent} />` stays the FIRST script in `<head>`;
  `<ConsentBanner config={consent} />` at the end of `<body>`. WordPress: no other plugin or
  theme option may add GA4/GTM/Ads tags.
- Styling: only the `--consent-*` variables listed in the package README, section "Theming"
  (colours, fonts, corners, shadow, dim colour and blur behind the windows, outline buttons,
  switches), set on `:root` in this site's CSS. Never style `.w360c-*` classes or the windows'
  HTML: they are internal. Layout, the modal layer behind the windows, text sizes and the equal
  "Reject all" / "Accept all" buttons are fixed. Missing a variable? Ask for it in the package
  repo. Check contrast of the colours you choose (text 4.5:1, switch "off" and focus ring 3:1).
- The footer always has "Cookie settings" (`data-consent-open`, or `[w360_cookie_settings]`
  on WordPress). The privacy policy has the cookie section from the package's
  `templates/privacy-cookies.<lang>.md`, kept in sync with the tags actually used.
- When a tag or category is added or removed: raise `version` in the consent config (everyone
  is asked again) and update the privacy policy cookie list in the same change.
- Tag IDs (GA4_ID, GOOGLE_ADS_ID, GTM_ID) are configuration (Worker vars / plugin settings),
  added at go-live only.
- Before launch, and after any tag change, run the package's `templates/go-live-checklist.md`
  and include the results in the report.
