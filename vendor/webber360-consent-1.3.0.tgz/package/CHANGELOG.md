# Changelog

All notable changes. Versions follow semver; a released version never changes.

## 1.3.0 — 2026-11-10

- Fix: Cookie settings opened with a focus ring on the privacy policy link. Focus now goes to
  the window's title (as in the first-visit popup), with no ring; Tab moves on with the ring as
  before.
- New theme variables for the outline buttons (first window "Reject all", and both buttons under
  "Save choices"). Defaults keep the 1.2.0 look:
  - `--consent-outline-border`: first window the text colour, preferences `--consent-border`
  - `--consent-outline-bg`: `transparent`
  - `--consent-outline-text`: the text colour
  - `--consent-outline-hover-bg`: `--consent-surface-2`
  - `--consent-outline-hover-border`: the border at rest
- New theme variables for the switches. Defaults keep the 1.2.0 look:
  - `--consent-switch-off`: `--consent-surface-2`
  - `--consent-switch-ring`: `--consent-muted` (`transparent` removes the ring; the track must
    then carry the 3:1 contrast, WCAG 1.4.11)
  - `--consent-switch-on`: `--consent-strong-bg`
  - `--consent-switch-knob`: `--consent-knob` (still works), else the window background
  - `--consent-switch-knob-on`: `--consent-accent`
- Fix: no blur behind the windows in Safari before 18. Both windows now also set
  `-webkit-backdrop-filter`. Checked in Safari 17.6: no blur with 1.2.0, blur with 1.3.0.
- CI also runs the focus tests in WebKit (Safari's engine). Playwright's WebKit draws no blur
  behind dialogs at all, so there the blur tests are marked as expected to fail; a unit test
  checks that both windows keep the prefixed property.
- README "Theming" rewritten as a guide for whoever installs the package on a site: what a site
  can change (all variables, by area) and what stays fixed (layout, the modal layer behind the
  windows, text sizes, equal Reject all / Accept all, accessibility). The site snippet
  (`templates/CLAUDE-site-snippet.md`) points to it and says not to style `.w360c-*` classes.
- No change to texts, layout, cookies, Consent Mode or tag loading: sites need not raise their
  `version`.

## 1.2.0 — 2026-11-04

- The page behind the Cookie settings window is now blurred too, like behind the first-visit
  popup. `--consent-backdrop-blur` (default 4px) sets the blur for both windows; `0` turns it
  off.
- No change to cookies, Consent Mode or tag loading: sites need not raise their `version`.

## 1.1.0 — 2026-11-04

- New theme variables: `--consent-title-leading` (title line height, default 1.2) and
  `--consent-focus` (keyboard focus ring colour, default the text colour). Without them
  everything looks as in 1.0.0.
- `*words*` in `text`, `prefsIntro` and the category descriptions show in italics. Texts are
  still never parsed as HTML.
- DE and HU texts reviewed and approved (unchanged).
- Dev tooling upgraded (Playwright 1.64, vitest 5, happy-dom 21, esbuild 0.28, TypeScript 5.9);
  CI back on `ubuntu-latest`. No effect on the built files.
- No change to cookies, Consent Mode or tag loading: sites need not raise their `version`.

## 1.0.0 — 2026-11-04

First release, extracted from brnd247.org's consent (Nov 2026).

- Google Consent Mode v2 head script (defaults denied, stored choice applied first).
- Centred popup (Reject all / Accept all, equal) and preferences window.
- GA4, Google Ads, GTM ("after-consent" and "advanced"), Cloudflare Web Analytics.
- Analytics, Marketing and optional Functional categories; cookie cleanup on withdrawal.
- EN / DE / HU texts, per-site overrides.
- `data-consent` blocking for site scripts and iframes; `onConsent`, `W360Consent` API,
  `w360:consent` event, `consent_update` dataLayer event.
- Astro components, standalone bundle, WordPress plugin (settings page, WP Consent API).
- Cookie format compatible with brnd247.org's `brnd_consent` (4-part value).
