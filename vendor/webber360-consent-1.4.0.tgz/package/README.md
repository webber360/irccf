# @webber360/consent

GDPR cookie consent with **Google Consent Mode v2** for W360 sites: Astro, WordPress and plain
HTML. Private package, © W360 OÜ.

- A centred popup on the first visit. **Reject all** (left) and **Accept all** (right) have the same size and place, and **Choose cookies** opens the per-category preferences.
- Consent Mode v2 defaults (all optional signals denied) are set first in `<head>`. A stored choice is applied before any tag can load.
- GA4, Google Ads, Google Tag Manager and Cloudflare Web Analytics load only for the categories the visitor granted. Withdrawing consent deletes the cookies they set.
- English, German and Hungarian texts, picked from `<html lang>`. Every text can be overridden.
- `data-consent` blocks the site's own scripts and iframes until their category is granted.
- WordPress: a plugin with a settings page that reports the choice to the WP Consent API.
- Accessible: native modal dialogs, focus on the heading (no answer pre-selected), WCAG 2.1 AA (axe-tested in light and dark mode).

## How it works

| Piece                                     | Where                        | What it does                                                                                          |
| ----------------------------------------- | ---------------------------- | ----------------------------------------------------------------------------------------------------- |
| Head script (`head.min.js`, ~2.4 KB)      | first script in `<head>`     | `gtag('consent','default', …denied)`, applies a stored choice, loads GTM in "advanced" mode           |
| Config (`#w360-consent-config` JSON)      | end of `<body>`              | site name, privacy URL, tag IDs, texts                                                                |
| Popup (`consent.min.js` / `autoInit()`)   | end of `<body>`              | asks, stores the choice, `gtag('consent','update')`, loads tags, clears cookies                       |
| Cookie `w360_consent` (name configurable) | first-party, 180 days, `Lax` | `<version>.<unix-time>.<analytics>.<marketing>[.<functional>]`. Raising `version` asks everyone again |

## Install

The repo is private, so a release is a file that each site keeps in its own repo. Cloudflare
Workers Builds then needs no GitHub access or token. Download a release (needs `gh` signed in as
a user with access to `webber360/consent`). Find the latest version first, then use it in the
commands below (1.4.0 in the examples):

```bash
gh release view -R webber360/consent --json tagName,publishedAt
```

```bash
gh release download v1.4.0 -R webber360/consent -p 'webber360-consent-1.4.0.tgz' -D vendor
```

### Astro

```bash
npm i ./vendor/webber360-consent-1.4.0.tgz
```

`src/consent.config.ts`:

```ts
import type { ConsentConfig } from "@webber360/consent";
import { env } from "cloudflare:workers"; // or import.meta.env

export const consent: ConsentConfig = {
  siteName: "Example",
  privacyUrl: "/privacy/",
  ga4: env.GA4_ID, // invalid or empty IDs load nothing
  googleAds: env.GOOGLE_ADS_ID,
  // gtm: { id: env.GTM_ID, mode: "after-consent" },
};
```

Layout:

```astro
---
import ConsentHead from "@webber360/consent/astro/ConsentHead.astro";
import ConsentBanner from "@webber360/consent/astro/ConsentBanner.astro";
import { consent } from "../consent.config";
---

<html lang="en">
  <head>
    <meta charset="utf-8" />
    <ConsentHead config={consent} />
    <!-- before every other script -->…
  </head>
  <body>
    …
    <footer>
      <button type="button" data-consent-open>
        Cookie settings
      </button>
    </footer>
    <ConsentBanner config={consent}>
      <Logo slot="logo" />
      <!-- optional -->
    </ConsentBanner>
  </body>
</html>
```

`astro.config.mjs`: the integration registers the site for
[compliance monitoring](#compliance-monitoring-by-w360) on each build (since 1.4.0). It needs
`site`, and it never fails a build.

```js
import w360Consent from "@webber360/consent/integration";

export default defineConfig({
  site: "https://example.org",
  integrations: [w360Consent()],
});
```

### WordPress

```bash
gh release download v1.4.0 -R webber360/consent -p 'webber360-consent-wp-*.zip'
```

1. Upload the zip under **Plugins → Add New → Upload Plugin**, then activate it.
2. Under **Settings → Cookie consent**, fill in the site name, privacy URL, tag IDs, GTM mode and colours.
3. Put `[w360_cookie_settings]` in the footer. Any link with `data-consent-open` also works.
4. Remove every other plugin or theme setting that adds GA4, GTM or Ads tags (for example Site Kit's own snippet). Otherwise those tags load without consent.

Since 1.4.0 the plugin registers a live site for [compliance monitoring](#compliance-monitoring-by-w360)
by itself (on by default; switch it off under **Settings → Cookie consent**).

Developers can change the full config with the `w360_consent_config` filter, for example to set texts:

```php
add_filter('w360_consent_config', function ($c) {
    $c['texts'] = ['de' => ['title' => 'Helfen Sie uns']];
    return $c;
});
```

### Any other HTML site

```html
<head>
  <script data-w360-consent='{"siteName":"Example","privacyUrl":"/privacy/","ga4":"G-XXXX"}'>
    /* contents of head.min.js */
  </script>
  <link rel="stylesheet" href="/consent.min.css" />
</head>
<body>
  …
  <script type="application/json" id="w360-consent-config">
    { "siteName": "Example", "privacyUrl": "/privacy/", "ga4": "G-XXXX" }
  </script>
  <script src="/consent.min.js" defer></script>
</body>
```

From JS or TS there are `headTag(config)` and `configTag(config)`, which return these tags as strings.

Register the site once for [compliance monitoring](#compliance-monitoring-by-w360), after it is
live:

```bash
curl -s -X POST https://consentreg.webber360.com/v1/register -H 'content-type: application/json' \
  -d '{"url":"https://example.org","platform":"html"}'
```

## Config

| Field                 | Default                       | Notes                                                                                                             |
| --------------------- | ----------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| `siteName`            | required                      | `{site}` in texts                                                                                                 |
| `privacyUrl`          | required                      | link in the preferences                                                                                           |
| `version`             | `1`                           | raise it when tags or categories change: everyone is asked again                                                  |
| `cookieName`          | `w360_consent`                | brnd247.org uses `brnd_consent`                                                                                   |
| `maxAgeDays`          | `180`                         |                                                                                                                   |
| `ga4`                 |                               | `G-…`, loaded with Analytics                                                                                      |
| `googleAds`           |                               | `AW-…`, loaded with Marketing                                                                                     |
| `gtm`                 |                               | `{ id: "GTM-…", mode: "after-consent" \| "advanced" }`                                                            |
| `cloudflareAnalytics` |                               | site token, loaded with Analytics                                                                                 |
| `categories`          | from the tags                 | `analytics` (GA4/GTM/CF), `marketing` (Ads/GTM); add `"functional"` yourself                                      |
| `lang`                | from `<html lang>`, else `en` | `en`, `de` or `hu`                                                                                                |
| `texts`               |                               | `{ en: { title: "…" }, de: {…} }`: any key of `Texts` (`*italic*` allowed in body texts), see `src/i18n/index.ts` |
| `logo`                |                               | `{ src, alt, width, height }`, or a `<template data-w360-consent-logo>` (the Astro slot)                          |
| `cookiePatterns`      | Google `_ga`, `_gcl`, …       | extra regex sources per category, deleted on withdrawal                                                           |
| `adsDataRedaction`    | `true`                        |                                                                                                                   |
| `waitForUpdate`       | `500`                         | ms                                                                                                                |

**GTM modes.**

- `after-consent` is GDPR-strict and the default: the container loads only after the visitor grants a category.
- `advanced` loads GTM on every page, and its tags read the Consent Mode signals. Google then receives cookieless pings from visitors who haven't agreed. That's a legal decision for the site owner.
- In both modes, don't configure GA4 both here and inside GTM, or every visit counts twice.

## Site scripts that need consent

```html
<script
  type="text/plain"
  data-consent="marketing"
  data-src="https://connect.facebook.net/…"
></script>
<script type="text/plain" data-consent="analytics">
  /* inline code */
</script>
<iframe data-consent="functional" data-src="https://www.youtube-nocookie.com/embed/…"></iframe>
```

From code:

```ts
import { onConsent } from "@webber360/consent";
onConsent((c) => {
  if (c.marketing) loadPixel();
});
// or, without a bundler: window.W360Consent.on(cb) / .get() / .open()
// or listen for the "w360:consent" window event; GTM gets a dataLayer event "consent_update".
```

## Compliance monitoring by W360

Since 1.4.0, W360 OÜ checks every live site that runs the package once a month: a browser visits
it in each consent state and checks its cookies against GDPR and Google Consent Mode v2 (see
[Cookie scanner](#cookie-scanner)). Problems and new cookies are reported to W360.

- **What is sent to W360:** the site's address, its name and the package version, server to
  server, at registration and (WordPress) once a day. **No visitor data**, and nothing ever runs
  in visitors' browsers for this.
- **How a site registers:** WordPress by itself; Astro through the integration on each build;
  any other site with one command at install (see Install). Staging copies, `localhost` and other
  non-public addresses never register.
- **Switching it off:** `"monitoring": false` in the consent config (WordPress: untick **Let W360
  check this site once a month**; Astro: also `w360Consent({ monitoring: false })`). W360 then
  stops checking the site and deletes its stored results. Remove the setting to switch it on again.
- **WordPress shows the results** under Settings → Cookie consent → Latest compliance scan: the
  date, any violations in plain words, and the site's cookies by category with provider, purpose
  and duration. **Scan now** asks for an extra scan, done with the next daily run (within 24
  hours, once a day).
- **Applying the scan (WordPress):** the same page lists the scan's suggested changes (a category
  to ask for, cookie patterns to delete on withdrawal) with **Apply suggested changes**, and a
  small form for each cookie the scan could not name. Applying only ever adds; a new category
  raises the consent `version`, so every visitor is asked again. A category only stops cookies
  from tags the package loads and from content marked `data-consent`: a script added another way
  keeps setting its cookies until it is wrapped or removed, and the scan keeps reporting it.
- **Astro and other sites:** the site's `cookie-scan` issue lists the suggested config changes;
  apply them in the site's repo.
- Visitors are never affected: the banner works the same whether monitoring is on or off, and
  whether the registry can be reached or not.

### Cookie list for the privacy policy

The site's cookies from its latest monthly scan, by category (in the banner's words), with
provider, purpose and duration, in English, German or Hungarian. It never calls W360 from a
visitor's browser.

- **WordPress:** `[w360_cookie_list]` (or `[w360_cookie_list lang="de"]`; default: the plugin's
  language, else the site's). Refreshed with the daily check-in; cookies an admin reviewed show
  in the admin's words.
- **Astro:** loaded when the site is built; rebuild after the monthly scan to update it.

  ```astro
  ---
  import CookieList from "@webber360/consent/astro/CookieList.astro";
  ---

  <CookieList site="https://example.org" lang="de" />
  ```

- **Other sites:** the site's `cookie-scan` issue contains the list as HTML, in the three
  languages, ready to paste.

Tell clients about the monthly check before their site gets 1.4.0 (it is on by default).

## Theming

The windows take a site's design through CSS variables only. Set them on `:root` in the site's
own stylesheet. On WordPress the settings page offers the accent colours; put every other
variable in the theme's CSS (or **Appearance → Customize → Additional CSS**). Every variable is
optional, and without them the windows follow the visitor's light/dark setting. The same list,
with defaults, is at the top of `src/styles/consent.css`.

The `.w360c-*` class names and the HTML inside the windows are internal and may change in any
release. Don't style them from a site: if something can't be set with a variable, ask for a new
variable in this repo.

### What a site can change

| Area             | Variables (since)                                                                                                                                                                             |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Window colours   | `--consent-bg`, `--consent-text`, `--consent-muted` (secondary text), `--consent-border` (dividers), `--consent-surface-2` (hover fill)                                                       |
| Accept all       | `--consent-accent`, `--consent-accent-text`, `--consent-accent-hover`                                                                                                                         |
| Save choices     | `--consent-strong-bg`, `--consent-strong-text`, `--consent-strong-hover`                                                                                                                      |
| Outline buttons  | `--consent-outline-border`, `--consent-outline-bg`, `--consent-outline-text`, `--consent-outline-hover-bg`, `--consent-outline-hover-border` (1.3.0)                                          |
| Switches         | `--consent-switch-off`, `--consent-switch-ring`, `--consent-switch-on`, `--consent-switch-knob`, `--consent-switch-knob-on` (1.3.0); `--consent-knob` (older name of `--consent-switch-knob`) |
| Typography       | `--consent-font`, `--consent-heading-font`, `--consent-title-leading` (1.1.0)                                                                                                                 |
| Shape and depth  | `--consent-radius` (window corners), `--consent-btn-radius` (button corners), `--consent-shadow`                                                                                              |
| Behind the page  | `--consent-backdrop` (dim colour behind the first window), `--consent-scrim` (behind Cookie settings), `--consent-backdrop-blur` (1.2.0; both windows, `0` turns the blur off)                |
| Keyboard focus   | `--consent-focus` (1.1.0; ring colour)                                                                                                                                                        |
| Content (config) | `logo`, `texts` per language (`*words*` show in italics since 1.1.0; texts are never parsed as HTML), `siteName`, `privacyUrl`: see [Config](#config)                                         |

Outline buttons are "Reject all" in the first window and both buttons under "Save choices".
Defaults of the 1.3.0 variables (all keep the 1.2.0 look):

| Variable                         | Default                                                      |
| -------------------------------- | ------------------------------------------------------------ |
| `--consent-outline-border`       | text colour (first window), `--consent-border` (preferences) |
| `--consent-outline-bg`           | `transparent`                                                |
| `--consent-outline-text`         | text colour                                                  |
| `--consent-outline-hover-bg`     | `--consent-surface-2`                                        |
| `--consent-outline-hover-border` | the border at rest                                           |
| `--consent-switch-off`           | `--consent-surface-2`                                        |
| `--consent-switch-ring`          | `--consent-muted` (`transparent` = no ring)                  |
| `--consent-switch-on`            | `--consent-strong-bg`                                        |
| `--consent-switch-knob`          | `--consent-knob`, else the window background                 |
| `--consent-switch-knob-on`       | `--consent-accent`                                           |

### What stays fixed

These are part of the package, the same on every site:

- **Layout and position**: both windows are centred modal dialogs of fixed width over the page.
  The order of elements, spacing, padding and button height (at least 44px, a touch target) are
  fixed.
- **The layer behind the windows**: while a window is open the page sits behind a dimmed
  (by default blurred) layer and can't be used until the visitor answers or presses Esc. A site can change
  the dim colour and the blur strength (see above), not remove the layer or the modal behaviour.
- **Text sizes and weights**: set in `rem`, so they follow the site's root font size, but the
  steps between title, text and buttons are fixed.
- **Refusing is as easy as agreeing**: "Reject all" and "Accept all" always have the same size,
  type and row, in both windows. No variable changes this (GDPR,
  EDPB guidelines on deceptive design patterns). When theming, also keep them equally visible:
  don't give Reject all a colour that makes it look disabled or secondary next to Accept all.
- **Accessibility**: the focus ring's width and offset, the 3:1 contrast of the "off" switch
  (WCAG 1.4.11) and the reduced-motion handling. Colours are the site's choice, so the site is
  responsible for their contrast: text 4.5:1 against the window, the "off" switch 3:1 from the
  ring or the track (if you remove the ring, the track must carry it), the focus ring 3:1.
- **Animation**: the fade and scale on opening.

### Examples

Mapping brnd247's tokens:

```css
:root {
  --consent-bg: var(--color-surface);
  --consent-text: var(--color-text);
  --consent-muted: var(--color-text-muted);
  --consent-accent: var(--color-accent);
  --consent-font: var(--font-body);
  --consent-heading-font: var(--font-heading);
  --consent-title-leading: var(--leading-title);
  --consent-focus: var(--color-focus);
  --consent-backdrop-blur: 4px;
}
```

A ghost outline button whose border turns to the ink colour on hover (1.3.0):

```css
:root {
  --consent-outline-border: var(--line-2);
  --consent-outline-text: var(--ink);
  --consent-outline-hover-border: var(--ink);
  --consent-outline-hover-bg: transparent;
}
```

## Before a site goes live

Use `templates/go-live-checklist.md`, and add the cookie section from
`templates/privacy-cookies.<lang>.md` to the privacy policy.

Paste `templates/CLAUDE-site-snippet.md` into the site's CLAUDE.md, with the version filled in, so
the site's development sessions keep to these rules.

## Upgrading a site

Sites never update by themselves: each one keeps its release file until someone upgrades it.

**Hearing about a release.** On GitHub, **Watch → Custom → Releases** on `webber360/consent` sends
an email for every release. Or check with `gh release view -R webber360/consent`. Dependabot can't
see a local release file, so it won't open upgrade PRs.

**How big the change is.** Read the release's entry in `CHANGELOG.md`:

- Patch (1.1.x): a fix. Upgrade as below.
- Minor (1.x): new options; nothing breaks. Use the new options where they help.
- Major (2.0): something breaks. The changelog says what each site must change.

**Astro**

```bash
gh release download vX.Y.Z -R webber360/consent -p 'webber360-consent-X.Y.Z.tgz' -D vendor
```

```bash
npm i ./vendor/webber360-consent-X.Y.Z.tgz
```

Then delete the old `.tgz` from `vendor/`, update the version in the site's CLAUDE.md section,
check the popup (first visit, Reject all, Accept all, Cookie settings) and commit the release file,
`package.json` and the lockfile together. In a site's CLAUDE.md the upgrade counts as a dependency
upgrade, so it needs approval like any other.

**WordPress**

Download `webber360-consent-wp-X.Y.Z.zip` from the release and upload it under **Plugins → Add New
→ Upload Plugin**, choosing to replace the installed version. The settings are kept.

**Upgrading doesn't ask visitors again.** Only the site's own consent `version` does that. Raise it
when the site adds or removes a tag or category, not for a package upgrade.

## Development

```bash
npm ci
npx playwright install chromium
npm run check        # prettier, tsc, unit tests, build, Playwright (desktop + mobile)
npm run pack:release # release/ files, as the release workflow builds them
```

For releases, see `CLAUDE.md`. Versions follow semver, and a tag is never moved.

## Cookie scanner

A repo tool, not part of the files sites install. It visits a site in a real browser, in each
consent state (no choice yet, Reject all, Accept all, each category alone, after withdrawing),
and reports:

- **Violations** of GDPR and Google Consent Mode v2: optional cookies, storage or trackers before a
  choice or after Reject all; the Consent Mode default missing, late or not denying
  `ad_storage`, `analytics_storage`, `ad_user_data` and `ad_personalization`; Google receiving
  granted consent before a choice; a wrong update after a choice; cookies left after withdrawing;
  a missing banner; Reject all and Accept all not equal.
- **Every cookie**, named from `scan/known-cookies.ts` (provider, category, purpose, duration).
  Unknown cookies are marked "needs review", never guessed.
- **Suggested changes**: categories to show, `cookiePatterns`, and whether to raise `version`.
  Nothing is changed automatically.

```bash
npm run scan -- https://example.org            # up to 20 pages from the sitemap
npm run scan -- https://example.org --pages 5 --include /contact/,/shop/ --out scan-results
```

It writes `scan-results/<host>.md` and `<host>.json` and exits with 1 when it finds a violation.
Measurement hits (Google, Meta, LinkedIn, TikTok, Microsoft) are answered locally and never sent,
so the scan doesn't show up in the site's statistics.

**Monthly run** (`.github/workflows/monthly-scan.yml`, daily at 04:23 UTC): asks the
[registry](registry/README.md) which sites are due (each active site once a month, spread over
days 1-28; a site missed on its day is added within 35 days), scans them, stores the reports and
keeps one GitHub issue per site, labelled `cookie-scan`:

- opened when a scan finds violations, new cookies, or cookies that need review;
- commented on when a later scan finds something new; nothing is posted when nothing changed;
- closed when a scan is clean.

Every run also updates the pinned issue **Cookie scan overview** (label `cookie-scan-overview`):
all registered sites with platform, version, status, last check-in, latest scan and their open
issue. It is edited in place, so it sends no daily notifications.

GitHub emails the repo's watchers about these issues. Run it by hand under **Actions →
monthly-scan → Run workflow**, for one day of the month or for one registered site (`url`, scanned
straight away). Locally:
`CONSENTREG_RUNNER_TOKEN=… SCAN_DAY=18 DRY_RUN=1 npm run scan:day` prints the issues instead of
writing them.
