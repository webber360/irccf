# @webber360/consent

GDPR cookie consent with **Google Consent Mode v2** for W360 sites: Astro, WordPress and plain
HTML. Private package, © W360 OÜ.

- A centred popup on the first visit. **Reject all** (left) and **Accept all** (right) have the same size and place, and **Choose cookies** opens the per-category preferences.
- Consent Mode v2 defaults (all optional signals denied) are set first in `<head>`. A stored choice is applied before any tag can load.
- GA4, Google Ads, Google Tag Manager and Cloudflare Web Analytics load only for the categories the visitor granted. Withdrawing consent deletes the cookies they set.
- English, German and Hungarian texts, picked from `<html lang>`. Every text can be overridden.
- `data-consent` blocks the site's own scripts and iframes until their category is granted.
- WordPress: a plugin with a settings page that reports the choice to the WP Consent API.
- Accessible: native modal dialogs, focus on the heading (no answer pre-selected), WCAG 2.1 AA (axe-tested in light and dark mode).

## How it works

| Piece                                     | Where                        | What it does                                                                                          |
| ----------------------------------------- | ---------------------------- | ----------------------------------------------------------------------------------------------------- |
| Head script (`head.min.js`, ~2.4 KB)      | first script in `<head>`     | `gtag('consent','default', …denied)`, applies a stored choice, loads GTM in "advanced" mode           |
| Config (`#w360-consent-config` JSON)      | end of `<body>`              | site name, privacy URL, tag IDs, texts                                                                |
| Popup (`consent.min.js` / `autoInit()`)   | end of `<body>`              | asks, stores the choice, `gtag('consent','update')`, loads tags, clears cookies                       |
| Cookie `w360_consent` (name configurable) | first-party, 180 days, `Lax` | `<version>.<unix-time>.<analytics>.<marketing>[.<functional>]`. Raising `version` asks everyone again |

## Install

The repo is private, so a release is a file that each site keeps in its own repo. Cloudflare
Workers Builds then needs no GitHub access or token. Download a release (needs `gh` signed in as
a user with access to `webber360/consent`). Find the latest version first, then use it in the
commands below (1.2.0 in the examples):

```bash
gh release view -R webber360/consent --json tagName,publishedAt
```

```bash
gh release download v1.2.0 -R webber360/consent -p 'webber360-consent-1.2.0.tgz' -D vendor
```

### Astro

```bash
npm i ./vendor/webber360-consent-1.2.0.tgz
```

`src/consent.config.ts`:

```ts
import type { ConsentConfig } from "@webber360/consent";
import { env } from "cloudflare:workers"; // or import.meta.env

export const consent: ConsentConfig = {
  siteName: "Example",
  privacyUrl: "/privacy/",
  ga4: env.GA4_ID, // invalid or empty IDs load nothing
  googleAds: env.GOOGLE_ADS_ID,
  // gtm: { id: env.GTM_ID, mode: "after-consent" },
};
```

Layout:

```astro
---
import ConsentHead from "@webber360/consent/astro/ConsentHead.astro";
import ConsentBanner from "@webber360/consent/astro/ConsentBanner.astro";
import { consent } from "../consent.config";
---

<html lang="en">
  <head>
    <meta charset="utf-8" />
    <ConsentHead config={consent} />
    <!-- before every other script -->…
  </head>
  <body>
    …
    <footer>
      <button type="button" data-consent-open>
        Cookie settings
      </button>
    </footer>
    <ConsentBanner config={consent}>
      <Logo slot="logo" />
      <!-- optional -->
    </ConsentBanner>
  </body>
</html>
```

### WordPress

```bash
gh release download v1.2.0 -R webber360/consent -p 'webber360-consent-wp-*.zip'
```

1. Upload the zip under **Plugins → Add New → Upload Plugin**, then activate it.
2. Under **Settings → Cookie consent**, fill in the site name, privacy URL, tag IDs, GTM mode and colours.
3. Put `[w360_cookie_settings]` in the footer. Any link with `data-consent-open` also works.
4. Remove every other plugin or theme setting that adds GA4, GTM or Ads tags (for example Site Kit's own snippet). Otherwise those tags load without consent.

Developers can change the full config with the `w360_consent_config` filter, for example to set texts:

```php
add_filter('w360_consent_config', function ($c) {
    $c['texts'] = ['de' => ['title' => 'Helfen Sie uns']];
    return $c;
});
```

### Any other HTML site

```html
<head>
  <script data-w360-consent='{"siteName":"Example","privacyUrl":"/privacy/","ga4":"G-XXXX"}'>
    /* contents of head.min.js */
  </script>
  <link rel="stylesheet" href="/consent.min.css" />
</head>
<body>
  …
  <script type="application/json" id="w360-consent-config">
    { "siteName": "Example", "privacyUrl": "/privacy/", "ga4": "G-XXXX" }
  </script>
  <script src="/consent.min.js" defer></script>
</body>
```

From JS or TS there are `headTag(config)` and `configTag(config)`, which return these tags as strings.

## Config

| Field                 | Default                       | Notes                                                                                                             |
| --------------------- | ----------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| `siteName`            | required                      | `{site}` in texts                                                                                                 |
| `privacyUrl`          | required                      | link in the preferences                                                                                           |
| `version`             | `1`                           | raise it when tags or categories change: everyone is asked again                                                  |
| `cookieName`          | `w360_consent`                | brnd247.org uses `brnd_consent`                                                                                   |
| `maxAgeDays`          | `180`                         |                                                                                                                   |
| `ga4`                 |                               | `G-…`, loaded with Analytics                                                                                      |
| `googleAds`           |                               | `AW-…`, loaded with Marketing                                                                                     |
| `gtm`                 |                               | `{ id: "GTM-…", mode: "after-consent" \| "advanced" }`                                                            |
| `cloudflareAnalytics` |                               | site token, loaded with Analytics                                                                                 |
| `categories`          | from the tags                 | `analytics` (GA4/GTM/CF), `marketing` (Ads/GTM); add `"functional"` yourself                                      |
| `lang`                | from `<html lang>`, else `en` | `en`, `de` or `hu`                                                                                                |
| `texts`               |                               | `{ en: { title: "…" }, de: {…} }`: any key of `Texts` (`*italic*` allowed in body texts), see `src/i18n/index.ts` |
| `logo`                |                               | `{ src, alt, width, height }`, or a `<template data-w360-consent-logo>` (the Astro slot)                          |
| `cookiePatterns`      | Google `_ga`, `_gcl`, …       | extra regex sources per category, deleted on withdrawal                                                           |
| `adsDataRedaction`    | `true`                        |                                                                                                                   |
| `waitForUpdate`       | `500`                         | ms                                                                                                                |

**GTM modes.**

- `after-consent` is GDPR-strict and the default: the container loads only after the visitor grants a category.
- `advanced` loads GTM on every page, and its tags read the Consent Mode signals. Google then receives cookieless pings from visitors who haven't agreed. That's a legal decision for the site owner.
- In both modes, don't configure GA4 both here and inside GTM, or every visit counts twice.

## Site scripts that need consent

```html
<script
  type="text/plain"
  data-consent="marketing"
  data-src="https://connect.facebook.net/…"
></script>
<script type="text/plain" data-consent="analytics">
  /* inline code */
</script>
<iframe data-consent="functional" data-src="https://www.youtube-nocookie.com/embed/…"></iframe>
```

From code:

```ts
import { onConsent } from "@webber360/consent";
onConsent((c) => {
  if (c.marketing) loadPixel();
});
// or, without a bundler: window.W360Consent.on(cb) / .get() / .open()
// or listen for the "w360:consent" window event; GTM gets a dataLayer event "consent_update".
```

## Theming

Set any `--consent-*` variable on `:root`. The full list is at the top of `src/styles/consent.css`. For example, mapping brnd247's tokens:

```css
:root {
  --consent-bg: var(--color-surface);
  --consent-text: var(--color-text);
  --consent-muted: var(--color-text-muted);
  --consent-accent: var(--color-accent);
  --consent-font: var(--font-body);
  --consent-heading-font: var(--font-heading);
  --consent-title-leading: var(--leading-title); /* since 1.1.0 */
  --consent-focus: var(--color-focus); /* since 1.1.0 */
  --consent-backdrop-blur: 4px; /* behind both windows since 1.2.0; 0 turns it off */
}
```

In `text`, `prefsIntro` and the category descriptions, `*words*` show in italics (since 1.1.0).
Texts are never parsed as HTML.

Keep Reject all and Accept all equal in size and place. Making refusal harder than agreeing breaks GDPR (EDPB guidelines on deceptive design patterns).

## Before a site goes live

Use `templates/go-live-checklist.md`, and add the cookie section from
`templates/privacy-cookies.<lang>.md` to the privacy policy.

Paste `templates/CLAUDE-site-snippet.md` into the site's CLAUDE.md, with the version filled in, so
the site's development sessions keep to these rules.

## Upgrading a site

Sites never update by themselves: each one keeps its release file until someone upgrades it.

**Hearing about a release.** On GitHub, **Watch → Custom → Releases** on `webber360/consent` sends
an email for every release. Or check with `gh release view -R webber360/consent`. Dependabot can't
see a local release file, so it won't open upgrade PRs.

**How big the change is.** Read the release's entry in `CHANGELOG.md`:

- Patch (1.1.x): a fix. Upgrade as below.
- Minor (1.x): new options; nothing breaks. Use the new options where they help.
- Major (2.0): something breaks. The changelog says what each site must change.

**Astro**

```bash
gh release download vX.Y.Z -R webber360/consent -p 'webber360-consent-X.Y.Z.tgz' -D vendor
```

```bash
npm i ./vendor/webber360-consent-X.Y.Z.tgz
```

Then delete the old `.tgz` from `vendor/`, update the version in the site's CLAUDE.md section,
check the popup (first visit, Reject all, Accept all, Cookie settings) and commit the release file,
`package.json` and the lockfile together. In a site's CLAUDE.md the upgrade counts as a dependency
upgrade, so it needs approval like any other.

**WordPress**

Download `webber360-consent-wp-X.Y.Z.zip` from the release and upload it under **Plugins → Add New
→ Upload Plugin**, choosing to replace the installed version. The settings are kept.

**Upgrading doesn't ask visitors again.** Only the site's own consent `version` does that. Raise it
when the site adds or removes a tag or category, not for a package upgrade.

## Development

```bash
npm ci
npx playwright install chromium
npm run check        # prettier, tsc, unit tests, build, Playwright (desktop + mobile)
npm run pack:release # release/ files, as the release workflow builds them
```

For releases, see `CLAUDE.md`. Versions follow semver, and a tag is never moved.
