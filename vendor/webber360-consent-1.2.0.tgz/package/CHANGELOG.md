# Changelog

All notable changes. Versions follow semver; a released version never changes.

## 1.2.0 — 2026-11-04

- The page behind the Cookie settings window is now blurred too, like behind the first-visit
  popup. `--consent-backdrop-blur` (default 4px) sets the blur for both windows; `0` turns it
  off.
- No change to cookies, Consent Mode or tag loading: sites need not raise their `version`.

## 1.1.0 — 2026-11-04

- New theme variables: `--consent-title-leading` (title line height, default 1.2) and
  `--consent-focus` (keyboard focus ring colour, default the text colour). Without them
  everything looks as in 1.0.0.
- `*words*` in `text`, `prefsIntro` and the category descriptions show in italics. Texts are
  still never parsed as HTML.
- DE and HU texts reviewed and approved (unchanged).
- Dev tooling upgraded (Playwright 1.64, vitest 5, happy-dom 21, esbuild 0.28, TypeScript 5.9);
  CI back on `ubuntu-latest`. No effect on the built files.
- No change to cookies, Consent Mode or tag loading: sites need not raise their `version`.

## 1.0.0 — 2026-11-04

First release, extracted from brnd247.org's consent (Nov 2026).

- Google Consent Mode v2 head script (defaults denied, stored choice applied first).
- Centred popup (Reject all / Accept all, equal) and preferences window.
- GA4, Google Ads, GTM ("after-consent" and "advanced"), Cloudflare Web Analytics.
- Analytics, Marketing and optional Functional categories; cookie cleanup on withdrawal.
- EN / DE / HU texts, per-site overrides.
- `data-consent` blocking for site scripts and iframes; `onConsent`, `W360Consent` API,
  `w360:consent` event, `consent_update` dataLayer event.
- Astro components, standalone bundle, WordPress plugin (settings page, WP Consent API).
- Cookie format compatible with brnd247.org's `brnd_consent` (4-part value).
