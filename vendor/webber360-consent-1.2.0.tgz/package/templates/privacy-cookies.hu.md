<!-- Süti szakasz az adatvédelmi tájékoztatóhoz. Csak a ténylegesen használt szolgáltatások
     sorait tartsa meg; cserélje ki: {SITE}, {COOKIE}. A végleges szöveget jogászzal ellenőriztesse. -->

### Sütik és hasonló tárolás

A szükséges tárolás az oldal működéséhez kell, és nem igényel hozzájárulást. Minden más az Ön döntésére vár a süti-ablakban. A Google Consent Mode-ot használjuk: amíg nem járul hozzá, a Google címkék semmit sem tárolnak az eszközén.

- **{COOKIE}** · {SITE} · Szükséges · 6 hónap · Megjegyzi a süti-választását.
- **\_ga**, **\_ga\_…** · Google Analytics · Statisztika, hozzájárulással · 2 év · Megkülönbözteti a látogatásokat.
- **\_gcl\_…** · Google Ads · Marketing, hozzájárulással · 90 nap · Hirdetési konverziók mérése.
- **Google Tag Manager** · Google · a fenti címkéket csak hozzájárulás után tölti be · maga nem állít be sütit.
- **Cloudflare Web Analytics** · Cloudflare · Statisztika, hozzájárulással · nincs süti · Névtelen látogatásszámok.

**Döntése módosítása.** Nyissa meg a **Süti-beállítások** linket bármely oldal alján. Ha visszavonja hozzájárulását, leállítjuk a címkéket, és töröljük az általuk a domainünkön beállított sütiket. A sütiket a böngésző beállításaiban is letilthatja vagy törölheti, illetve használhatja a Google [letiltó bővítményét](https://tools.google.com/dlpage/gaoptout?hl=hu).
