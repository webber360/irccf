# Cookie consent go-live checklist

Run on the production URL in a fresh private window. Record the result of each step in the
launch report.

## Before any choice

- [ ] The popup opens after the page has loaded. Reject all is on the left, Accept all on the right, and they're the same size.
- [ ] DevTools → Network, filtered by `google|gtm|doubleclick|facebook|cloudflareinsights`: no requests. The one exception is `gtm.js` in GTM "advanced" mode.
- [ ] DevTools → Application → Cookies: only necessary cookies (the consent cookie appears only after a choice). No `_ga`, `_gcl` or `_fbp`.
- [ ] Console: `dataLayer[0]` is `['consent','default',{… 'denied' …}]` and comes before any `config`, `gtm.js` or `event` entry.

## Reject all

- [ ] The consent cookie ends `.0.0` (or `.0.0.0` with a functional category).
- [ ] Still no Google requests or cookies, after reloading and on another page.

## Accept all (in a new private window)

- [ ] A `consent update` entry shows `granted` for the accepted categories.
- [ ] GA4: `collect?v=2` requests are sent, with `gcs=G111` (or `G1x1` for analytics only).
- [ ] GA4 Realtime (or DebugView) shows the visit.
- [ ] Google Tag Assistant (tagassistant.google.com) → Consent tab: the defaults are denied, then the update is granted.

## Withdrawal

- [ ] Footer "Cookie settings" opens the preferences with the current choice ticked.
- [ ] Untick Analytics and save: the `_ga` cookies are gone, and the next page sends no `collect` requests.

## Content and legal

- [ ] Texts are in the site's language; DE and HU have been checked by a native speaker.
- [ ] The privacy policy has the cookie section, listing every cookie actually set (compare with DevTools after Accept all).
- [ ] Keyboard: Tab reaches every button, and Esc closes the popup. Screen reader: the heading is announced first.
- [ ] Mobile, about 375 px wide: everything fits with no horizontal scrolling.
