<!-- Cookie-Abschnitt für die Datenschutzerklärung. Nur die Zeilen der tatsächlich genutzten
     Dienste behalten; {SITE}, {COOKIE} ersetzen. Endfassung juristisch prüfen lassen. -->

### Cookies und ähnliche Speicher

Notwendige Speicher halten die Website funktionsfähig und benötigen keine Einwilligung. Alles andere wartet auf Ihre Auswahl im Cookie-Fenster. Wir nutzen den Google Consent Mode: Bis Sie zustimmen, speichern Google-Tags nichts auf Ihrem Gerät.

- **{COOKIE}** · {SITE} · Notwendig · 6 Monate · Speichert Ihre Cookie-Auswahl.
- **\_ga**, **\_ga\_…** · Google Analytics · Statistik, mit Einwilligung · 2 Jahre · Unterscheidet Besuche.
- **\_gcl\_…** · Google Ads · Marketing, mit Einwilligung · 90 Tage · Misst Werbe-Conversions.
- **Google Tag Manager** · Google · lädt die obigen Tags erst nach Einwilligung · setzt selbst keine Cookies.
- **Cloudflare Web Analytics** · Cloudflare · Statistik, mit Einwilligung · keine Cookies · Anonyme Besuchszahlen.

**Auswahl ändern.** Öffnen Sie **Cookie-Einstellungen** unten auf jeder Seite. Wenn Sie Ihre Einwilligung widerrufen, stoppen wir die Tags und löschen die Cookies, die sie auf unserer Domain gesetzt haben. Sie können Cookies auch in Ihren Browser-Einstellungen blockieren oder löschen oder das [Deaktivierungs-Add-on](https://tools.google.com/dlpage/gaoptout?hl=de) von Google nutzen.
