<!-- Cookie section for the privacy policy. Keep only the rows for tags the site uses; replace
     {SITE}, {COOKIE} (consent cookie name) and {DAYS}. Have the final text reviewed. -->

### Cookies and similar storage

Necessary storage keeps the site working and needs no consent. Everything else waits for your choice in the cookie popup. We use Google Consent Mode: until you agree, Google tags store nothing on your device.

- **{COOKIE}** · {SITE} · Necessary · 6 months · Remembers your cookie choice.
- **\_ga**, **\_ga\_…** · Google Analytics · Analytics, with consent · 2 years · Distinguish visits.
- **\_gcl\_…** · Google Ads · Marketing, with consent · 90 days · Measure ad conversions.
- **Google Tag Manager** · Google · loads the tags above, only after consent · sets no cookies itself.
- **Cloudflare Web Analytics** · Cloudflare · Analytics, with consent · no cookies · Anonymous visit counts.

**Changing your choice.** Open **Cookie settings** at the bottom of any page. If you withdraw consent, we stop the tags and delete the cookies they set on our domain. You can also block or delete cookies in your browser's settings, or use Google's [opt-out add-on](https://tools.google.com/dlpage/gaoptout).
